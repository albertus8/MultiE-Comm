<?php
/**
 * Created by albertus
 * Project MultiE-Comm
 * on Feb 2017.
 */
?>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h3 class="panel-title"><i class="fa fa-table"></i> Data Tables</h3>
            </div>
            <div class="panel-body">


                <div id="myModal" class="modal fade" role="dialog">
                    <div class="modal-dialog">

                        <!-- Modal content-->
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                <h4 class="modal-title">Detail Nota Penjualan</h4>
                            </div>
                            <div class="modal-body">
                                <div style="float: left">
                                    <table>
                                        <tr>
                                            <td>
                                                Search
                                            </td>
                                            <td>
                                                : <input type='text' name='searchBox' id='searchBox' />
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                                <br />
                                <hr />
                                <pre>

                                 </pre>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>
</div>


</div>
