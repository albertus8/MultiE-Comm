<!-- Bootstrap Core JavaScript -->
<script src="<?php echo base_url("assets/js/bootstrap.min.js"); ?>"></script>

<!-- Morris Charts JavaScript -->
<script src="<?php echo base_url("assets/js/plugins/morris/raphael.min.js"); ?>"></script>
<script src="<?php echo base_url("assets/js/plugins/morris/morris.min.js"); ?>"></script>
<script src="<?php echo base_url("assets/js/plugins/morris/morris-data.js"); ?>"></script>